# AV5 - Jogos e Músicas (SQLAlchemy + SQLite/MySQL)

Programa de terminal que insere, lista e exclui dados de duas classes
relacionadas 1 para N: **Jogo** (1) -> **Musica** (N).
O usuário escolhe o banco (SQLite ou MySQL) e pode trocar durante a execução.

## 1. Enviar o programa para o repositório

1. `uv init`
2. `uv add sqlalchemy pymysql python-dotenv`
3. Criar o `.gitignore` contendo `.env` e `venv/`
4. `git init`
5. `git add .`
6. `git commit -m "Primeira versao do programa AV5"`
7. `git branch -M main`
8. `git remote add origin URL_DO_REPOSITORIO`
9. `git push -u origin main`

## 2. Baixar e executar em outra máquina

1. `git clone URL_DO_REPOSITORIO`
2. `cd NOME_DA_PASTA`
3. `uv sync`
4. Copiar `.env.example` para `.env` e preencher com os dados do MySQL local
5. Criar o banco no MySQL: `mysql -u root -p -e "CREATE DATABASE av5;"`
6. `uv run main.py`

> O SQLite não precisa de configuração: o arquivo `jogo.db` é criado sozinho.
> O arquivo `.env` não é enviado ao repositório (está no `.gitignore`).
