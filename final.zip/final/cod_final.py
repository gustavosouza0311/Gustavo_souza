import os
import time
from typing import Optional

from dotenv import load_dotenv
from sqlalchemy import ForeignKey, String, create_engine, select
from sqlalchemy.engine import URL
from sqlalchemy.orm import (DeclarativeBase,Mapped,Session,mapped_column,relationship,)



class Base(DeclarativeBase):
    pass


class Jogo(Base):
    __tablename__ = "jogo"

    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(250))
    empresa: Mapped[str] = mapped_column(String(250))
    quantidade: Mapped[str] = mapped_column(String(250))
    lancamento: Mapped[Optional[str]] = mapped_column(String(250), nullable=True)

    musicas: Mapped[list["Musica"]] = relationship(
        back_populates="jogo", cascade="all, delete-orphan"
    )


class Musica(Base):
    __tablename__ = "musicas"

    id: Mapped[int] = mapped_column(primary_key=True)
    bandas: Mapped[str] = mapped_column(String(250))
    cantores: Mapped[str] = mapped_column(String(250))
    quantidade: Mapped[str] = mapped_column(String(250))
    tempo: Mapped[Optional[str]] = mapped_column(String(250), nullable=True)
    jogo_id: Mapped[int] = mapped_column(ForeignKey("jogo.id"))

    jogo: Mapped["Jogo"] = relationship(back_populates="musicas")

def ler_numero(texto, minimo, maximo):
    """Pede um número entre minimo e maximo até o usuário digitar certo."""
    while True:
        try:
            valor = int(input(texto))
        except ValueError:
            print("Digite apenas números!")
            continue
        if minimo <= valor <= maximo:
            return valor
        print("Perdeu 67 mil de aura ;-;")
        texto = "Escolha um número válido: "


def ler_texto(texto, obrigatorio=True):
    """Pede um texto. Se obrigatorio, não aceita vazio."""
    while True:
        valor = input(texto).strip()
        if valor or not obrigatorio:
            return valor or None
        print("Esse campo não pode ficar vazio.")


def conectar_sqlite():
    engine = create_engine("sqlite:///jogo.db")
    Base.metadata.create_all(engine)
    print("Conectado ao SQLite!")
    return engine


def conectar_mysql():
    """Lê os dados de conexão do arquivo .env (não vai para o git)."""
    load_dotenv()
    usuario = os.getenv("MYSQL_USER")
    senha = os.getenv("MYSQL_PASSWORD")
    host = os.getenv("MYSQL_HOST")
    porta = os.getenv("MYSQL_PORT")
    banco = os.getenv("MYSQL_DATABASE")

    if not all([usuario, senha is not None, host, porta, banco]):
        print("Faltam variáveis no arquivo .env (veja o .env.example).")
        return None

    url = URL.create(
        "mysql+pymysql",
        username=usuario,
        password=senha,
        host=host,
        port=int(porta),
        database=banco,
    )
    try:
        engine = create_engine(url)
        with engine.connect():
            pass
        Base.metadata.create_all(engine)
    except Exception as erro:
        print("Não foi possível conectar ao MySQL.")
        print("Detalhe:", erro)
        return None

    print("Conectado ao MySQL!")
    return engine


# OPERAÇÕES
def escolher_tabela():
    print("\n[ 1 ] Jogo\n[ 2 ] Música")
    return ler_numero("Com qual tabela? ", 1, 2)


def inserir(session):
    if escolher_tabela() == 1:
        jogo = Jogo(
            nome=ler_texto("Nome do jogo: "),
            empresa=ler_texto("Empresa: "),
            quantidade=ler_texto("Quantidade de músicas nesse jogo: "),
            lancamento=ler_texto("Data de lançamento (opcional): ", False),
        )
        session.add(jogo)
        session.commit()
        print(f"Jogo inserido com o jogo {jogo.id}!")
    else:
        jogos = session.scalars(select(Jogo)).all()
        if not jogos:
            print("Cadastre um jogo primeiro, a música precisa pertencer a um jogo.")
            return
        print("\nJogos cadastrados:")
        for j in jogos:
            print(f"  id {j.id} - {j.nome}")
        ids = [j.id for j in jogos]
        while True:
            jogo_id = ler_numero("Id do jogo dessa música: ", 1, 10**9)
            if jogo_id in ids:
                break
            print("Esse id não existe.")
        musica = Musica(
            bandas=ler_texto("Banda(s): "),
            cantores=ler_texto("Cantor(es): "),
            quantidade=ler_texto("Quantidade de músicas: "),
            tempo=ler_texto("Tempo total (opcional): ", False),
            jogo_id=jogo_id,
        )
        session.add(musica)
        session.commit()
        print(f"Música inserida com id {musica.id}!")


def listar(session):
    if escolher_tabela() == 1:
        jogos = session.scalars(select(Jogo)).all()
        if not jogos:
            print("Nenhum jogo cadastrado.")
        for j in jogos:
            print(
                f"\n[{j.id}] {j.nome} | empresa: {j.empresa} | "
                f"músicas: {j.quantidade} | lançamento: {j.lancamento or '-'}"
            )
            for m in j.musicas:
                print(f"     -> música {m.id}: {m.bandas} / {m.cantores}")
    else:
        musicas = session.scalars(select(Musica)).all()
        if not musicas:
            print("Nenhuma música cadastrada.")
        for m in musicas:
            print(
                f"\n[{m.id}] bandas: {m.bandas} | cantores: {m.cantores} | "
                f"quantidade: {m.quantidade} | tempo: {m.tempo or '-'} | "
                f"jogo: {m.jogo.nome}"
            )


def excluir(session):
    tabela = escolher_tabela()
    modelo = Jogo if tabela == 1 else Musica
    registro_id = ler_numero("Id para excluir: ", 1, 10**9)
    registro = session.get(modelo, registro_id)
    if registro is None:
        print("Não encontrei esse id.")
        return
    if tabela == 1 and registro.musicas:
        print(f"Atenção: as {len(registro.musicas)} música(s) desse jogo também serão excluídas.")
    confirma = input("Tem certeza? (s/n): ").strip().lower()
    if confirma == "s":
        session.delete(registro)
        session.commit()
        print("Excluído!")
    else:
        print("Cancelado.")



# MENUS
def menu_bancos():
    print("""
|===============================|
|                               |
|        {  DATABASE  }         |
|                               |
|        [ 1 ] SQLITE           |
|        [ 2 ] MYSQL            |
|        [ 3 ] SAIR             |
|                               |
|===============================|""")
    time.sleep(1)
    return ler_numero("Escolha o que você quer fazer : ", 1, 3)


def menu_operacoes(engine, nome_banco):
    """Retorna True se o usuário quer sair do programa, False se quer trocar de banco."""
    while True:
        print(f"""
|-----------------------------|
|                             |
|      {{ MENU DE OPÇÕES  }}    |
|      Banco: {nome_banco:<16}|
|                             |
|       [ 1 ] Inserir         |
|       [ 2 ] Listar          |
|       [ 3 ] Excluir         |
|       [ 4 ] Trocar banco    |
|       [ 5 ] Sair            |
|                             |
|-----------------------------|""")
        time.sleep(1)
        opcao = ler_numero("Escolha o que você quer fazer : ", 1, 5)
        if opcao == 4:
            return False
        if opcao == 5:
            return True
        with Session(engine) as session:
            if opcao == 1:
                inserir(session)
            elif opcao == 2:
                listar(session)
            elif opcao == 3:
                excluir(session)


def main():
    while True:
        escolha = menu_bancos()
        if escolha == 3:
            break
        if escolha == 1:
            engine, nome = conectar_sqlite(), "SQLite"
        else:
            engine, nome = conectar_mysql(), "MySQL"
        if engine is None:
            continue
        sair = menu_operacoes(engine, nome)
        engine.dispose()
        if sair:
            break
    print("Até mais!")


if __name__ == "__main__":
    main()
