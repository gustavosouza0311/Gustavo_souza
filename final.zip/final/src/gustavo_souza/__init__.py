def main() -> None:
    print("Hello from gustavo-souza!")
